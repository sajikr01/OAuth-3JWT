package com.jwt.example.jwtexample;

import lombok.*;
import org.springframework.stereotype.Component;

@Data
@Component

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class JwtResponse {
    private String jwtToken;
    private String username;
}
