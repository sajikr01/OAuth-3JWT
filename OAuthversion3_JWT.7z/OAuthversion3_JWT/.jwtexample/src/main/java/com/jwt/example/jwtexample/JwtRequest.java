package com.jwt.example.jwtexample;

import lombok.*;
import org.springframework.stereotype.Component;

@Data
@Component

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class JwtRequest {
    private String email;
    private String password;
}
